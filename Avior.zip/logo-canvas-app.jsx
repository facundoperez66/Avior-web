/* Avior — logo redesign canvas */
const { useMemo } = React;

const PALETTE = { bg:'#131110', cream:'#ede7da', terra:'#c9543b' };

// ---- Icon: squircle + mascot SVG ----
function Icon({ size = 'lg', bg, opts }) {
  const px = { lg:184, md:46, sm:34, xs:24, xxs:17 }[size];
  const svgPx = Math.round(px * 0.66);
  const sw = size === 'lg' ? 9 : size === 'md' ? 12 : size === 'sm' ? 13 : 16;
  const html = window.aviorMascot({ ...opts, bg, sw });
  return (
    <div className={`squircle ${size}`} style={{ background: bg }}>
      <div
        style={{ width: svgPx, height: svgPx }}
        dangerouslySetInnerHTML={{
          __html: `<svg width="${svgPx}" height="${svgPx}" viewBox="0 0 256 256" fill="none">${html}</svg>`,
        }}
      />
    </div>
  );
}

function Wordmark({ cls = 'lg' }) {
  return (
    <span className={`wm ${cls}`}>Avior<sup>®</sup></span>
  );
}

// ---- One variation card ----
function Variation({ v }) {
  return (
    <div className="vcard">
      <div className="v-hero">
        <Icon size="lg" bg={v.squircleBg} opts={v.mascot} />
      </div>

      <div className="v-lockup">
        <Icon size="md" bg={v.squircleBg} opts={v.mascot} />
        <div className="lk-text">
          <Wordmark cls="lg" />
          <span className="lockup-tag">Soluciones digitales</span>
        </div>
      </div>

      <div className="v-dark">
        <Icon size="md" bg={v.squircleBg} opts={v.mascot} />
        <Wordmark cls="md" />
        <span className="nav-meta">en la web</span>
      </div>

      <div className="v-sizes">
        <span className="lbl">Escala</span>
        <Icon size="sm" bg={v.squircleBg} opts={v.mascot} />
        <Icon size="xs" bg={v.squircleBg} opts={v.mascot} />
        <Icon size="xxs" bg={v.squircleBg} opts={v.mascot} />
      </div>

      <div className="v-note">
        <div className="nm">{v.label}</div>
        <div className="ds">{v.note}</div>
      </div>
    </div>
  );
}

const VARIATIONS = [
  {
    id: 'a', label: 'A · Marca línea',
    squircleBg: '#131110',
    mascot: { mode: 'line', line: '#ede7da', nose: '#c9543b' },
    note: 'La opción que elegiste, ahora con el bulldog inglés: monolínea crema sobre el negro cálido de la marca, orejas caídas y nariz terracota. El registro más sobrio y editorial, idéntico en tono a la web.',
  },
  {
    id: 'b', label: 'B · Terracota',
    squircleBg: '#c9543b',
    mascot: { mode: 'line', line: '#ede7da', nose: '#131110' },
    note: 'Terracota como protagonista: el cuadrado se vuelve el color de marca y el bulldog salta a la vista. Rasgos en crema, nariz en negro para contraste.',
  },
  {
    id: 'c', label: 'C · Silueta sólida',
    squircleBg: '#131110',
    mascot: { mode: 'solid', fill: '#c9543b', feat: '#ede7da', nose: '#131110' },
    note: 'El bulldog como silueta sólida en terracota con los rasgos calados en crema. Más rotunda y reconocible a tamaños mínimos (favicon, app).',
  },
  {
    id: 'd', label: 'D · Claro',
    squircleBg: '#ede7da',
    mascot: { mode: 'line', line: '#1a1714', nose: '#c9543b' },
    note: 'Versión para fondos claros, papelería e impresión. Trazo en negro cálido sobre crema, con la nariz terracota manteniendo el acento.',
  },
];

function App() {
  return (
    <DesignCanvas>
      <DCSection
        id="logos"
        title="Avior — Rediseño del logo"
        subtitle="Bulldog inglés redibujado limpio y geométrico · orejas caídas · terracota protagonista · ícono + logotipo"
      >
        {VARIATIONS.map(v => (
          <DCArtboard key={v.id} id={v.id} label={v.label} width={400} height={668}>
            <Variation v={v} />
          </DCArtboard>
        ))}
      </DCSection>
    </DesignCanvas>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
