/* AVIOR — panel de Tweaks */
const AVIOR_TWEAKS = /*EDITMODE-BEGIN*/{
  "heroVariant": "a",
  "accent": "#c9543b",
  "motion": "full",
  "grain": true
}/*EDITMODE-END*/;

function AviorTweaks() {
  const [t, setTweak] = useTweaks(AVIOR_TWEAKS);

  React.useEffect(() => {
    document.body.setAttribute("data-hero", t.heroVariant);
  }, [t.heroVariant]);

  React.useEffect(() => {
    document.documentElement.style.setProperty("--accent", t.accent);
  }, [t.accent]);

  React.useEffect(() => {
    document.documentElement.setAttribute("data-motion", t.motion === "min" ? "min" : "full");
  }, [t.motion]);

  React.useEffect(() => {
    document.querySelectorAll(".hero-grain").forEach(g => { g.style.display = t.grain ? "" : "none"; });
  }, [t.grain]);

  const heroLabels = { a: "Editorial centrado", b: "Split + imagen", c: "Kinético tipográfico" };

  return (
    <TweaksPanel>
      <TweakSection label="Portada (Hero)" />
      <TweakSelect
        label="Versión"
        value={t.heroVariant}
        options={[
          { value: "a", label: "A · Editorial centrado" },
          { value: "b", label: "B · Split + imagen" },
          { value: "c", label: "C · Kinético tipográfico" }
        ]}
        onChange={(v) => setTweak("heroVariant", v)}
      />

      <TweakSection label="Identidad" />
      <TweakColor
        label="Acento"
        value={t.accent}
        options={["#c9543b", "#d98b3a", "#a7563f", "#b8493f", "#7d8a5c"]}
        onChange={(v) => setTweak("accent", v)}
      />

      <TweakSection label="Movimiento" />
      <TweakRadio
        label="Animación"
        value={t.motion}
        options={[{ value: "full", label: "Completa" }, { value: "min", label: "Mínima" }]}
        onChange={(v) => setTweak("motion", v)}
      />
      <TweakToggle
        label="Textura de grano"
        value={t.grain}
        onChange={(v) => setTweak("grain", v)}
      />
    </TweaksPanel>
  );
}

(function mountTweaks() {
  const el = document.getElementById("tweaks-root");
  if (el && window.ReactDOM) {
    ReactDOM.createRoot(el).render(<AviorTweaks />);
  }
})();
